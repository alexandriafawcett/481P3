﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPSC481P3
{
    /// <summary>
    /// Interaction logic for ItemTileControl.xaml
    /// </summary>
    public partial class ItemTileControl : UserControl
    {
        public int index;

        public ItemTileControl(Image image, string imageName, int price, int i)
        {
            InitializeComponent();
            this.ItemTileName.Text = imageName;
            this.ItemTileImage.BeginInit();
            this.ItemTileImage.Source = image.Source;
            this.ItemTileImage.EndInit();            
            this.Price.Text = "$" + price;
            this.Quantity.Text = "0";
            this.index = i;
            
            this.AddItemTileButton.Click += OnAddButton;
            this.MinusItemTileButton.Click += OnSubButton;
        }

        private void OnSubButton(object sender, RoutedEventArgs e)
        {
            int q = Convert.ToInt32(this.Quantity.Text);
            if (q != 0) { q--; }           
            this.Quantity.Text = q.ToString();
        }

        private void OnAddButton(object sender, RoutedEventArgs e)
        {
            int q = Convert.ToInt32(this.Quantity.Text); 
            q++;
            this.Quantity.Text = q.ToString();
            
        }
    }
}
