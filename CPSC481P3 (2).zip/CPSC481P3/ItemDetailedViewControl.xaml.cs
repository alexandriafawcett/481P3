﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPSC481P3
{
    /// <summary>
    /// Interaction logic for ItemDetailedViewControl.xaml
    /// </summary>
    public partial class ItemDetailedViewControl : UserControl
    {
        public ItemTileControl tile;
        
        public Image ImageOfPhoto
        {
            get
            {
                return this.ImageOfPhoto;
            }
            set
            {
                this.EnlargedImage.BeginInit();
                this.EnlargedImage.Source = value.Source;
                this.EnlargedImage.EndInit();
                RevealContent();
            }
        }

        public string Label
        {
            get
            {
                return this.ItemName.Text;
            }
            set
            {
                this.ItemName.Text = value;
            }
        }

        public string Cost
        {
            get
            {
                return this.Price.Text;
            }

            set
            {
                this.Price.Text = value;
            }


        }

        public string Amount
        {
            get
            {
                return this.Quantity.Text;
            }

            set
            {
                this.Quantity.Text = value;
            }
        }

        private void RevealContent()
        {
            this.Visibility = Visibility.Visible;
            Storyboard sb = this.FindResource("ItemDetailAppear") as Storyboard;
            sb.Begin();
        }

        public ItemDetailedViewControl()
        {          

            InitializeComponent();
            this.DetailedViewExitButton.Click += OnCloseButton;
            this.IncreaseAmountButton.Click += onAddButton;
            this.DecreaseAmountButton.Click += onSubButton;
        }

    private void onSubButton(object sender, RoutedEventArgs e)
    {
        int q = Convert.ToInt32(this.Quantity.Text);
        if (q != 0) { q--; }
        this.Quantity.Text = q.ToString();
    }

    private void onAddButton(object sender, RoutedEventArgs e)
    {
        int q = Convert.ToInt32(this.Quantity.Text);
        q++;
        this.Quantity.Text = q.ToString();

    }

    private void OnCloseButton(object sender, RoutedEventArgs e)
        {
            Storyboard sb = this.FindResource("ItemDetailDisappear") as Storyboard;
            sb.Completed += OnDisappearCompleted;
            sb.Begin();
        }

        private void OnDisappearCompleted(object sender, EventArgs e)
        {           
            this.Visibility = Visibility.Hidden;
        }
    }
}
