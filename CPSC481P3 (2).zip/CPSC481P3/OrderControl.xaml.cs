﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPSC481P3
{
    /// <summary>
    /// Interaction logic for OrderControl.xaml
    /// </summary>
    public partial class OrderControl : UserControl
    {
        public OrderControl()
        {
            InitializeComponent();

            this.MinusItem.Click += onAddButton;
            this.PlusItem.Click += onSubButton;
        }

        private void onSubButton(object sender, RoutedEventArgs e)
        {
            int q = Convert.ToInt32(this.Quantity.Text);
            if (q != 0) { q--; }
            this.Quantity.Text = q.ToString();
        }

        private void onAddButton(object sender, RoutedEventArgs e)
        {
            int q = Convert.ToInt32(this.Quantity.Text);
            q++;
            this.Quantity.Text = q.ToString();

        }
    }
}
