﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CPSC481P3
{
    /// <summary>
    /// Interaction logic for ItemTileControl.xaml
    /// </summary>
    public partial class ItemTileControl : UserControl
    {
        public ItemTileControl(Image image, string imageName, int price)
        {
            InitializeComponent();
            this.ItemTileName.Text = imageName;
            this.ItemTileImage.BeginInit();
            this.ItemTileImage.Source = image.Source;
            this.ItemTileImage.EndInit();

            
            this.Price.Text = "$" + price;
        }
    }
}
